document.getElementById("redirectbutton").addEventListener("click", redirect);
function redirect(){ window.location = "chatbot.html";}