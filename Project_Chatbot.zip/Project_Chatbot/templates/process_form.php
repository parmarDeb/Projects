<?php
// Establish a MySQL connection (replace placeholders with your actual database credentials)
$host="localhost",
$user="root",
$password="Qwerty!!!7890",
$database="tnt"

$conn = new mysqli($localhost, $root, $Qwerty!!!7890, $tnt);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['username'];
$num = $_POST['usernumber'];

// Insert data into the database
$sql = "INSERT INTO userdetails (username, usercontact) VALUES ('$name', '$num')";

if ($conn->query($sql) === TRUE) {
    echo "Record added successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
