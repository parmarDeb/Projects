import random
import datetime
import qrcode
from flask import Flask, render_template, request, jsonify, session
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import mysql.connector
from tabulate import tabulate

app = Flask(__name__)

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Qwerty!!!7890",
    database="tnt"
)

cursor = mydb.cursor()

def check_exists():
    cursor.execute("SHOW TABLES LIKE 'menulist'")
    result = cursor.fetchone()
    if result:
        return True
    else:
        return False

def get_menu():
    cursor.execute("SELECT itemName, itemPrice FROM menulist")
    menu_items = cursor.fetchall()
    menu_dict = {item[0]: item[1] for item in menu_items}
    valid_items = list(menu_dict.keys())
    return valid_items, menu_dict

def suggest_dish():
    now = datetime.datetime.now()
    current_time = now.time()

    morning_range = datetime.time(6, 0, 0)
    afternoon_range = datetime.time(12, 0, 0)
    evening_range = datetime.time(18, 0, 0)

    if morning_range <= current_time < afternoon_range:
        morning_dishes = ["Tea", "Hot Coffee"]
        return random.choice(morning_dishes)
    elif afternoon_range <= current_time < evening_range:
        afternoon_dishes = ["Burger", "Pizza", "Sandwich"]
        return random.choice(afternoon_dishes)
    else:
        evening_dishes = ["Brownie", "Cold Coffee"]
        return random.choice(evening_dishes)



@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        username = request.form.get('name')
        usercontact = request.form.get('contact')

        query = "INSERT INTO userdetails (username, usercontact) VALUES (%s, %s)"
        cursor.execute(query, (username, usercontact))
        mydb.commit()

        result = get_payment_method()

        return render_template('chatbot.html', result=result)

    return render_template('index.html')

@app.route('/chatbot.html')
def chatbot():
    return render_template('chatbot.html')

@app.route('/backend', methods=['POST'])
def handle_user_message():
    if request.method == 'POST':
        data = request.json
        user_message = data.get('message', '')

        bot_response = generate_bot_response(user_message)
        order_process = process_order(user_message)

        return jsonify({'message': bot_response})
    elif request.method == 'GET':
        return jsonify({'message': 'This is a GET request'})

@app.route('/backend/get_menu', methods=['GET'])
def get_menu_route():
    valid_items, menu_dict = get_menu()
    menu_str = tabulate(menu_dict.items(), headers=["Item", "Price"], tablefmt="grid")
    return jsonify({'menu': menu_str})

@app.route('/backend/process_order', methods=['POST'])
def process_order_route():
    data = request.json
    order_message = data.get('order', '')
    result = process_order(order_message)
    return jsonify({'message': result['message'], 'order_added': result['order_added']})


def generate_bot_response(user_message):
    _, menu_dict = get_menu()

    if 'special' in user_message:
        special_dish = suggest_dish()
        return f"Our special for today is {special_dish}!"

    elif any(item in menu_dict for item in user_message.split(',')):
        for item in menu_dict:
            if True:
                order_message = user_message;
                user_order = [item.strip() for item in order_message.split(',')]    
                valid_order = [item for item in user_order if item in menu_dict]
                total_amount = sum(menu_dict[item] for item in valid_order)
                cursor.execute("SELECT username, usercontact FROM userdetails")
                details = cursor.fetchall()

                for username, usercontact in details:
                    c = canvas.Canvas("{} Receipt.pdf".format(username), pagesize=letter)

                    c.setFont("Helvetica-Bold", 16)
                    c.drawString(250, 750, "Talk n Treat")
                    c.drawString(249, 730, "***RECEIPT***")
                    c.drawString(100, 710, "Customer Name: {}".format(username))
                    c.drawString(100, 690, "Customer Contact: {}".format(usercontact))
                    c.drawString(100, 670, "Order Details:")

                    y_position = 650
                    for item in valid_order:
                        c.drawString(100, y_position, f"{item} = Rs.{menu_dict[item]}")
                        y_position -= 20

                    c.drawString(100, y_position - 10, "--------------------------------")
                    c.drawString(100, y_position - 30, "Total: Rs.{}".format(total_amount))

                    c.save()
                formatted_order = '\n'.join(valid_order)
                return f"Thanks for ordering: \n{formatted_order}. \nTotal Bill: ₹{total_amount}"
        
    elif 'payment' in user_message:
            return f"How would you like to pay? (Cash, Card, UPI): "
    
    elif 'upi' or 'card' or 'cash' in user_message:
        if user_message == 'cash':
            return f"Please pay your Bill in cash at the Reception."
        elif user_message == 'card':
            return f"Please insert or swipe your card at the Reception."
        elif user_message == 'upi':
            upi_data = "upi://pay?pa=9617413263@paytm&pn=Talk n Treat&mc=1234&tid=123456&tr=uniqueid&tn=Payment%20for%20Order"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(upi_data)
            qr.make(fit=True)
            qr_image = qr.make_image(fill_color="white", back_color="black")
            qr_image.save("upi_payment_qr.png")
            qr_image.show()        

            random_number = random.randint(1, 50)
            return f"Your order number is {random_number}. It will be ready soon. \n Thank You!"

    else:
        return "I'm sorry, I didn't understand that. How can I help you?"
    
def get_payment_method():
    return f"How would you like to pay? (Cash, Card, UPI): "

def ordered_item_list(order_message):
    _, menu_dict = get_menu()
    user_order = [item.strip() for item in order_message.split(',')]
    valid_order = [item for item in user_order if item in menu_dict]
    formatted_order = '\n'.join(valid_order)
    return f"Your order:\n{formatted_order}\n"

def process_order(order_message):
    _, menu_dict = get_menu()
    user_order = [item.strip() for item in order_message.split(',')]
    valid_order = [item for item in user_order if item in menu_dict]
    formatted_order = '\n'.join(valid_order)

    if valid_order:
        total_amount = sum(menu_dict[item] for item in valid_order)
        
        if 'bill' in order_message:
            return ordered_item_list(order_message)

        payment_method = get_payment_method()

        if payment_method == 'cash':
            print(f"Please pay ₹{total_amount} in cash at the Reception.")
        elif payment_method == 'card':
            print("Please insert or swipe your card at the Reception.")
        elif payment_method == 'upi':
            upi_data = "upi://pay?pa=9617413263@paytm&pn=Talk n Treat&mc=1234&tid=123456&tr=uniqueid&tn=Payment%20for%20Order"
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(upi_data)
            qr.make(fit=True)
            qr_image = qr.make_image(fill_color="white", back_color="black")
            qr_image.save("upi_payment_qr.png")
            qr_image.show()

        else:
            print("Invalid payment method. Please choose from Cash, Card, or UPI.")

        query = "INSERT INTO orders (itemName, itemPrice) VALUES (%s, %s)"
        cursor.executemany(query, [(item, menu_dict[item]) for item in valid_order])
        mydb.commit()

        cursor.execute("SELECT username, usercontact FROM userdetails")
        details = cursor.fetchall()

        for username, usercontact in details:
            c = canvas.Canvas("{} Receipt.pdf".format(username), pagesize=letter)

            c.setFont("Helvetica-Bold", 16)
            c.drawString(250, 750, "Talk n Treat")
            c.drawString(249, 730, "***RECEIPT***")
            c.drawString(100, 710, "Customer Name: {}".format(username))
            c.drawString(100, 690, "Customer Contact: {}".format(usercontact))
            c.drawString(100, 670, "Order Details:")

            y_position = 650
            for item in valid_order:
                c.drawString(100, y_position, f"{item} = Rs.{menu_dict[item]}")
                y_position -= 20

            c.drawString(100, y_position - 10, "--------------------------------")
            c.drawString(100, y_position - 30, "Total: Rs.{}".format(total_amount))

            c.save()
            order_info = f"Receipt saved as '{username} Receipt.pdf'. {formatted_order} added to cart."
            return {'message': f"Your Total Bill is: ₹{total_amount}. Your order will be ready in a short while! {formatted_order} added to cart.", 'order_added': True, 'order_info': order_info}
        
        return {'message': f"Your Total Bill is: ₹{total_amount}. Your order will be ready in a short while! {formatted_order} added to cart.", 'order_added': True}
    else:
        return {'message': "Invalid order. Please choose items from the menu and try again.", 'order_added': False}


if __name__ == '__main__':
    app.run(debug=True)
