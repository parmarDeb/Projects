import random
import datetime
from tabulate import tabulate
import mysql.connector
import qrcode
from PIL import Image
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

#Connect to the MySQL database
mydb = mysql.connector.connect(
    host = "localhost",
    user = "root",
    password = "Qwerty!!!7890",
    database = "tnt"
)

cursor = mydb.cursor()

def check_exists():
    cursor.execute("SHOW TABLES LIKE 'menulist'")
    result=cursor.fetchone()
    if result:
        return True
    else:
        return False

#Funtion to get the menu items and their prices from the database
def get_menu():
    cursor.execute("SELECT itemName, itemPrice FROM menulist")
    menu_items = cursor.fetchall()
    valid_items = [item[0] for item in menu_items]  # Extract valid item names
    return valid_items, dict(menu_items)

# Function to take the user's order 
def take_order():
    valid_items, menu_dict = get_menu()
    global Cust_name, Cust_contact
    Cust_name = input("Enter your name: ")
    Cust_contact = int(input("Enter Contact Number:"))
    print("What can I get you today?\n")
    valid_items_str = ', '.join(valid_items)
    print(tabulate(menu_dict.items(), headers=["Item", "Price"], tablefmt="grid"))
    user_order = input(f"Please type your order (choose from the Menu, separate items with a comma): ").split(',')
    order_list = [item.strip() for item in user_order if item.strip() in valid_items]

    while not order_list:
        print("Sorry, we don't have those items on the menu...")
        user_order = input(f"What would you like to order (choose from the Menu, separate items with a comma): ").split(',')
        order_list = [item.strip() for item in user_order if item.strip() in valid_items]
    return order_list

def generate_rt(user_order, total):
    valid_items, _ = get_menu()
    order_dict = {}  # Dictionary to store item quantities

    for item in user_order:
        if item in valid_items:
            order_dict[item] = order_dict.get(item, 0) + 1
    return order_dict

#Function to generate bill
def generate_bill(order_list):
    _, menulist = get_menu()
    global total
    total = 0

    print("\n***Bill***")
    for item in order_list:
        price = menulist[item]
        print(f"{item.capitalize()}-{price}")
        total+=price
    query = "insert into orders (itemName, itemPrice) VALUES (%s, %s)"
    cursor.executemany(query, [(item, menulist[item]) for item in order_list])
    mydb.commit()

    print(f"Total amount to be paid: ₹{total}")

def process_payment(total):
    payment_method = input("How would you like to pay? (Cash, Card, UPI): ").lower()
    if payment_method == 'cash':
        print(f"Please pay ₹{total} in cash at the Reception.")
    elif payment_method == 'card':
        print("Please insert or swipe your card at the Reception.")
        # Add code here to process card payment
    elif payment_method == 'upi':
        #upi_id = input("Please enter your UPI ID: ")
        #print(f"Please make a UPI payment of ₹{total} to {upi_id}.")
        # Add code here to process UPI payment
        # UPI payment information
        upi_data = "upi://pay?pa=9617413263@paytm&pn=Talk n Treat&mc=1234&tid=123456&tr=uniqueid&tn=Payment%20for%20Order"

        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(upi_data)
        qr.make(fit=True)
        # Create a QR code image
        qr_image = qr.make_image(fill_color="white", back_color="black")
        # Save the image
        qr_image.save("upi_payment_qr.png")
        # Display the image
        qr_image.show()
    
    else:
        print("Invalid payment method. Please choose from Cash, Card, or UPI.")

# Function to suggest a dish
def suggest_dish():
    now = datetime.datetime.now()
    current_time = now.time()

    # Define time ranges for suggestions
    morning_range = datetime.time(6, 0, 0)
    afternoon_range = datetime.time(12, 0, 0)
    evening_range = datetime.time(18, 0, 0)

    if morning_range <= current_time < afternoon_range:
        # Suggest breakfast items in the morning
        morning_dishes = ["Tea", "Hot Coffee"]
        return random.choice(morning_dishes)
    elif afternoon_range <= current_time < evening_range:
        # Suggest lunch items in the afternoon
        afternoon_dishes = ["Burger", "Pizza", "Sandwich"]
        return random.choice(afternoon_dishes)
    else:
        # Suggest dinner/snack items in the evening
        evening_dishes = ["Brownie", "Cold Coffee"]
        return random.choice(evening_dishes)

# Function to generate and save the PDF receipt
def generate_receipt(order_list, total):
    _, menulist = get_menu()

    # Create a PDF file named "receipt.pdf"
    c = canvas.Canvas("{} Receipt.pdf".format(Cust_name), pagesize=letter)
    
    # Create a title for the receipt
    c.setFont("Helvetica-Bold", 16)
    c.drawString(250, 750, "Talk n Treat")
    c.drawString(249, 730, "***RECEIPT***")
    c.drawString(100, 710, "Customer Name: {}".format(Cust_name))
    c.drawString(100, 690, "Customer Contact: {}".format(Cust_contact))
    c.drawString(100,670, "Order Details:")
    
    y_position = 650
    for item in order_list:
       c.drawString(100, y_position, f"{item} = Rs.{menulist[item]}")
       y_position -= 20
    
    c.drawString(100, y_position - 10, "--------------------------------")
    c.drawString(100, y_position - 30, "Total: Rs.{}".format(total))

    # Save the PDF
    c.save()
    print(f"Receipt saved as '{Cust_name} Receipt.pdf'")

# Main function to interact with the user
def restaurant_chatbot():
    print("*****Welcome To Talk n Treat Restaurant*****\n")
    order_list=[]
    order_dict={}
    print("Hello! I am your restaurant chatbot. I'm here to take your order and suggest dishes.")
    while True:
        user_input = input("What can I do for you today? (Type 'order' to place an order or 'suggest' for a suggestion): ").lower()
        
        if user_input == 'order':
            order = take_order()
            order_list.extend(order)
            print(f"Great choice! You've ordered {order}. Your {order} will be ready shortly.")
        elif user_input == 'suggest':
            suggested_dish = suggest_dish()
            print(f"I suggest you try our delicious {suggested_dish}.")
        else:
            print("Sorry, I didn't understand that. Please type 'order' to place an order or 'suggest' for a suggestion.")

        another_order = input("Would you like to do anything else? (yes/no): ").lower()
        if another_order != 'yes':
            break
    
    print(order_dict.items)
    print("order places!!!")
    if order_list:
        generate_bill(order_list)
        process_payment(total)
    else:
        print("Thank you for visiting. Have a great day!")

    # Generate and save the receipt
    if process_payment:
        generate_receipt(order_list, total)

# Start the chatbot
if __name__ == "__main__":

    if check_exists():
        print("Table exists!")

    restaurant_chatbot()